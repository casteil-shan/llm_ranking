"""Built-in benchmark suites."""
